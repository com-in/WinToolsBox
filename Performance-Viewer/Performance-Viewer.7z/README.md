#系统监控与数据记录 API

#简介

这是一个使用 Flask 构建的简单 Web API，用于监控系统资源（如 CPU、内存、磁盘使用情况）并记录数据。该 API 每秒收集一次系统信息，并将数据存储在 data.json 文件中。同时，提供一个 index.html 页面，用于实时展示系统数据。该页面使用本地加载的 ***Bootstrap*** 和 ***Chart.js*** 库，确保在离线环境下也能正常使用。

功能
实时监控：实时获取 CPU、内存、磁盘使用情况。
数据记录：将收集到的系统信息保存到本地 data.json 文件中。
数据获取：提供 API 接口供外部获取历史系统数据。
离线支持：提供 index.html 页面，支持离线使用，Bootstrap 和 Chart.js 库为本地加载。
跨域支持：通过 flask-cors 库支持跨域请求。
彩色日志：使用 colorlog 库实现彩色日志输出，便于调试和监控。

技术栈
 - Python 3.x
 - Flask
 - Flask-CORS
 - psutil
 - schedule
 - colorlog
 - Bootstrap (本地加载)
 - Chart.js (本地加载)