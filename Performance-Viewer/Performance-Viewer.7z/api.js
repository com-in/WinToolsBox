// 图表初始化
const cpuChart = createLineChart('cpuChart', 'CPU 使用率', 'rgba(75, 192, 192, 1)', 'rgba(75, 192, 192, 0.2)');
const memoryChart = createLineChart('memoryChart', '内存使用率', 'rgba(153, 102, 255, 1)', 'rgba(153, 102, 255, 0.2)');

// 定时更新数据
setInterval(updateSystemData, 1000);
updateSystemData();

// 创建折线图
function createLineChart(id, label, borderColor, backgroundColor) {
    const ctx = document.getElementById(id).getContext('2d');
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: label,
                data: [],
                borderColor: borderColor,
                backgroundColor: createGradient(ctx, borderColor),
                fill: true,
                pointRadius: 4,
                pointHoverRadius: 6,
                borderWidth: 3
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    title: { display: true, text: '时间', font: { size: 12 } },
                    ticks: { font: { size: 10 }, color: '#666' },
                    grid: { color: '#ddd', drawBorder: false }
                },
                y: {
                    title: { display: true, text: label, font: { size: 12 } },
                    beginAtZero: true,
                    max: 100,
                    ticks: { font: { size: 10 }, color: '#666' },
                    grid: { color: '#ddd', drawBorder: false }
                }
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: { font: { size: 12 }, color: '#333' }
                },
                tooltip: {
                    enabled: true,
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleFont: { size: 14 },
                    bodyFont: { size: 12 },
                    displayColors: false,
                    callbacks: {
                        label: function (context) {
                            return `${context.raw}%`;
                        }
                    }
                }
            }
        }
    });
}

// 创建渐变色背景
function createGradient(ctx, borderColor) {
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, borderColor.replace('1)', '0.1)')); // 较透明的颜色
    gradient.addColorStop(1, borderColor.replace('1)', '0.5)')); // 较深的颜色
    return gradient;
}

// 更新图表数据
function updateChart(chart, data, key) {
    const labels = data.map(item => new Date(item.timestamp * 1000).toLocaleTimeString());
    const values = data.map(item => item[key]);
    const maxDataPoints = 60;
    chart.data.labels = labels.slice(-maxDataPoints);
    chart.data.datasets[0].data = values.slice(-maxDataPoints);
    chart.update();
}

// 更新硬盘使用情况
function updateDiskUsage(diskLabel, data, progressBarId, textId, percentKey, usedKey, totalKey) {
    const progressBar = document.getElementById(progressBarId);
    const textElement = document.getElementById(textId);
    if (data[percentKey] !== null) {
        progressBar.style.width = data[percentKey] + '%';
        progressBar.setAttribute('aria-valuenow', data[percentKey]);
        textElement.textContent = `已用: ${data[usedKey]} GB / 总容量: ${data[totalKey]} GB (${data[percentKey]}%)`;
    } else {
        progressBar.style.width = '0%';
        progressBar.setAttribute('aria-valuenow', '0');
        textElement.textContent = `${diskLabel}: 盘未找到`;
    }
}

// 更新多核CPU信息
function updateCpuCores(corePercentages) {
    const cpuCoresDiv = document.getElementById('cpuCores');
    cpuCoresDiv.innerHTML = '';

    corePercentages.forEach((percentage, index) => {
        const coreBox = document.createElement('div');
        coreBox.className = 'cpu-core-box';
        coreBox.style.backgroundColor = getColor(percentage);
        coreBox.textContent = `核心 ${index + 1}: ${percentage.toFixed(2)}%`;
        cpuCoresDiv.appendChild(coreBox);
    });
}

// 确保页面加载完成后再执行脚本
document.addEventListener('DOMContentLoaded', () => {
    // 获取所有 .cpu-core-box 元素
    const boxes = document.querySelectorAll('.cpu-core-box');

    // 遍历每个元素，根据 data-percentage 设置背景颜色
    boxes.forEach(box => {
        // 获取 data-percentage 的值
        const percentage = parseFloat(box.getAttribute('data-percentage'));

        // 计算颜色
        const color = getColor(percentage);

        // 设置背景颜色
        box.style.backgroundColor = color;
    });
});

// 定义颜色计算函数
function getColor(percentage) {
    // 将百分比转换为 0 到 1 的范围
    const t = Math.min(1, Math.max(0, percentage / 100));

    // 定义颜色的起始值和结束值（RGB格式）
    const startColor = [0, 255, 0]; // 起始颜色：纯绿色
    const endColor = [255, 0, 0];   // 结束颜色：纯红色

    // 计算中间颜色
    const r = startColor[0] + (endColor[0] - startColor[0]) * t;
    const g = startColor[1] + (endColor[1] - startColor[1]) * t;
    const b = startColor[2] + (endColor[2] - startColor[2]) * t;

    // 定义透明度（可以根据需要调整透明度的计算方式）
    const a = 0.75; // 完全不透明

    // 返回 RGBA 格式的颜色字符串
    return `rgba(${Math.round(r)}, ${Math.round(g)}, ${Math.round(b)}, ${a})`;
}

// 更新系统数据
async function updateSystemData() {
    try {
        const response = await fetch('http://127.0.0.1:5000/api/sys/info/');
        if (!response.ok) throw new Error('Failed to fetch data');
        const data = await response.json();
        const latestData = data[data.length - 1];

        updateChart(cpuChart, data, 'cpu_percent');
        updateChart(memoryChart, data, 'memory_percent');
        updateDiskUsage('C', latestData, 'diskProgressC', 'diskTextC', 'disk_percent_c', 'disk_used_c', 'disk_total_c');
        updateDiskUsage('D', latestData, 'diskProgressD', 'diskTextD', 'disk_percent_d', 'disk_used_d', 'disk_total_d');
        updateCpuCores(latestData.cpu_percent_per_core);
    } catch (error) {
        console.error('Error fetching system data:', error);
    }
}