from flask import Flask, jsonify, request, send_file
from flask_cors import CORS
import psutil
import time
import schedule
from collections import deque
import threading
import platform
import json
import os
import logging
from colorlog import ColoredFormatter  # 导入 colorlog

app = Flask(__name__)
CORS(app)

data_queue = deque(maxlen=20)
lock = threading.Lock()  # 用于线程安全

# 获取系统和 CPU 型号
system_info = platform.system()
cpu_model = platform.processor()

# 数据文件路径
DATA_FILE = "data.json"

# 确保数据文件存在，如果不存在则创建一个空的 JSON 文件
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, "w") as file:
        json.dump([], file)

# 加载旧数据
def load_data():
    with open(DATA_FILE, "r") as file:
        data = json.load(file)
        # 将旧数据加载到队列中
        for item in data:
            data_queue.append(item)

# 保存数据到文件
def save_data():
    with lock:
        try:
            with open(DATA_FILE, "w") as file:
                json.dump(list(data_queue), file, indent=4)
            print(f"\033[92m数据已成功保存到 {DATA_FILE}\033[0m")  # 绿色提示
        except Exception as e:
            print(f"\033[91m保存数据到 {DATA_FILE} 时发生错误: {e}\033[0m")  # 红色错误

def get_disk_usage(disk):
    try:
        disk_usage = psutil.disk_usage(disk)
        disk_total = round(disk_usage.total / (1024.0 ** 3), 2)  # 转换为GB并四舍五入到两位小数
        disk_used = round(disk_usage.used / (1024.0 ** 3), 2)  # 转换为GB并四舍五入到两位小数
        disk_percent = round(disk_usage.percent, 2)  # 百分比也四舍五入到两位小数
        return disk_total, disk_used, disk_percent
    except Exception as e:
        print(f"\033[91mError occurred while getting disk usage for {disk}: {e}\033[0m")
        return 0.00, 0.00, 0.00  # 返回默认值，四舍五入到两位小数

def update_system_info():
    cpu_percent = psutil.cpu_percent(interval=1)
    cpu_percent_per_core = psutil.cpu_percent(interval=1, percpu=True)  # 获取每个 CPU 核心的使用率
    memory = psutil.virtual_memory()
    memory_percent = memory.percent
    # 获取内存总容量，转换为 GB 并保留两位小数
    memory_total = round(memory.total / (1024.0 ** 3), 2)

    disk_total_c, disk_used_c, disk_percent_c = get_disk_usage('C:')
    disk_total_d, disk_used_d, disk_percent_d = get_disk_usage('D:')

    # 将数据以字典形式存储到队列中
    with lock:
        data_queue.append({
            "timestamp": int(time.time()),  # 时间戳
            "system_info": system_info,  # 系统信息
            "cpu_model": cpu_model,  # CPU 型号
            "cpu_percent": cpu_percent,
            "cpu_percent_per_core": cpu_percent_per_core,  # 每个 CPU 核心的使用率
            "memory_percent": memory_percent,
            "memory_total": memory_total,  # 新增内存总容量
            "disk_total_c": disk_total_c,
            "disk_used_c": disk_used_c,
            "disk_percent_c": disk_percent_c,
            "disk_total_d": disk_total_d,
            "disk_used_d": disk_used_d,
            "disk_percent_d": disk_percent_d
        })

    # 每次更新后保存数据到文件
    save_data()

# 启动定时任务，每1秒更新一次
schedule.every(1).seconds.do(update_system_info)

def run_scheduled_tasks():
    while True:
        schedule.run_pending()
        time.sleep(1)

# 启动定时任务线程
threading.Thread(target=run_scheduled_tasks, daemon=True).start()

@app.route('/api/sys/info/', methods=['GET'])
def get_system_info():
    with lock:
        data = list(data_queue)
    return jsonify(data)

if __name__ == '__main__':
    # 加载旧数据
    load_data()
    # 启动 Flask 应用
    print(f"\033[92mPython\033[0m")
    print(f"\033[92m127.0.0.1:5000/api/sys/info/\033[0m")
    app.run(debug=False, port=5000)